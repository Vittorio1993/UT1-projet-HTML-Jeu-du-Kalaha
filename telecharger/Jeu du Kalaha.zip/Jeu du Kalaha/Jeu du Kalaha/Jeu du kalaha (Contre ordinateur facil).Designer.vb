﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Jeu_du_kalaha_Contre_ordinateur_dificile
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Jeu_du_kalaha_Contre_ordinateur_dificile))
        Me.lblordi = New System.Windows.Forms.Label()
        Me.lbljoueur1 = New System.Windows.Forms.Label()
        Me.btn13 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn10 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblordi
        '
        Me.lblordi.AutoSize = True
        Me.lblordi.BackColor = System.Drawing.Color.Transparent
        Me.lblordi.Font = New System.Drawing.Font("Monotype Corsiva", 18.0!, System.Drawing.FontStyle.Italic)
        Me.lblordi.Location = New System.Drawing.Point(945, 535)
        Me.lblordi.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblordi.Name = "lblordi"
        Me.lblordi.Size = New System.Drawing.Size(162, 44)
        Me.lblordi.TabIndex = 60
        Me.lblordi.Text = "Ordinateur"
        '
        'lbljoueur1
        '
        Me.lbljoueur1.AutoSize = True
        Me.lbljoueur1.BackColor = System.Drawing.Color.Transparent
        Me.lbljoueur1.Font = New System.Drawing.Font("Monotype Corsiva", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbljoueur1.Location = New System.Drawing.Point(39, 45)
        Me.lbljoueur1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbljoueur1.Name = "lbljoueur1"
        Me.lbljoueur1.Size = New System.Drawing.Size(129, 44)
        Me.lbljoueur1.TabIndex = 59
        Me.lbljoueur1.Text = "Joueur 1"
        '
        'btn13
        '
        Me.btn13.Location = New System.Drawing.Point(952, 268)
        Me.btn13.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(112, 91)
        Me.btn13.TabIndex = 58
        Me.btn13.Tag = ""
        Me.btn13.UseVisualStyleBackColor = True
        '
        'btn12
        '
        Me.btn12.Location = New System.Drawing.Point(808, 357)
        Me.btn12.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(112, 103)
        Me.btn12.TabIndex = 57
        Me.btn12.Tag = "12"
        Me.btn12.UseVisualStyleBackColor = True
        '
        'btn11
        '
        Me.btn11.Location = New System.Drawing.Point(687, 357)
        Me.btn11.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(112, 103)
        Me.btn11.TabIndex = 56
        Me.btn11.Tag = "11"
        Me.btn11.UseVisualStyleBackColor = True
        '
        'btn10
        '
        Me.btn10.Location = New System.Drawing.Point(566, 357)
        Me.btn10.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn10.Name = "btn10"
        Me.btn10.Size = New System.Drawing.Size(112, 103)
        Me.btn10.TabIndex = 55
        Me.btn10.Tag = "10"
        Me.btn10.UseVisualStyleBackColor = True
        '
        'btn9
        '
        Me.btn9.Location = New System.Drawing.Point(444, 357)
        Me.btn9.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(112, 103)
        Me.btn9.TabIndex = 54
        Me.btn9.Tag = "9"
        Me.btn9.UseVisualStyleBackColor = True
        '
        'btn8
        '
        Me.btn8.Location = New System.Drawing.Point(322, 357)
        Me.btn8.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(112, 103)
        Me.btn8.TabIndex = 53
        Me.btn8.Tag = "8"
        Me.btn8.UseVisualStyleBackColor = True
        '
        'btn7
        '
        Me.btn7.Location = New System.Drawing.Point(198, 357)
        Me.btn7.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(116, 103)
        Me.btn7.TabIndex = 52
        Me.btn7.Tag = "7"
        Me.btn7.UseVisualStyleBackColor = True
        '
        'btn6
        '
        Me.btn6.Location = New System.Drawing.Point(54, 268)
        Me.btn6.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(112, 91)
        Me.btn6.TabIndex = 51
        Me.btn6.Tag = ""
        Me.btn6.UseVisualStyleBackColor = True
        '
        'btn5
        '
        Me.btn5.Location = New System.Drawing.Point(201, 171)
        Me.btn5.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(112, 103)
        Me.btn5.TabIndex = 50
        Me.btn5.Tag = "5"
        Me.btn5.UseVisualStyleBackColor = True
        '
        'btn4
        '
        Me.btn4.Location = New System.Drawing.Point(322, 171)
        Me.btn4.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(112, 103)
        Me.btn4.TabIndex = 49
        Me.btn4.Tag = "4"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Location = New System.Drawing.Point(444, 171)
        Me.btn3.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(112, 103)
        Me.btn3.TabIndex = 48
        Me.btn3.Tag = "3"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Location = New System.Drawing.Point(566, 171)
        Me.btn2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(112, 103)
        Me.btn2.TabIndex = 47
        Me.btn2.Tag = "2"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Location = New System.Drawing.Point(687, 171)
        Me.btn1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(112, 103)
        Me.btn1.TabIndex = 46
        Me.btn1.Tag = "1"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn0
        '
        Me.btn0.Location = New System.Drawing.Point(808, 171)
        Me.btn0.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(112, 103)
        Me.btn0.TabIndex = 45
        Me.btn0.Tag = "0"
        Me.btn0.UseVisualStyleBackColor = True
        '
        'Jeu_du_kalaha_Contre_ordinateur_dificile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(1176, 659)
        Me.Controls.Add(Me.lblordi)
        Me.Controls.Add(Me.lbljoueur1)
        Me.Controls.Add(Me.btn13)
        Me.Controls.Add(Me.btn12)
        Me.Controls.Add(Me.btn11)
        Me.Controls.Add(Me.btn10)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn0)
        Me.Name = "Jeu_du_kalaha_Contre_ordinateur_dificile"
        Me.Text = "Jeu du kalaha (Contre ordinateur dificile)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblordi As Label
    Friend WithEvents lbljoueur1 As Label
    Friend WithEvents btn13 As Button
    Friend WithEvents btn12 As Button
    Friend WithEvents btn11 As Button
    Friend WithEvents btn10 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn1 As Button
    Friend WithEvents btn0 As Button
End Class
