﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Jeu_du_kalaha_Form_label
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Jeu_du_kalaha_Form_label))
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl9 = New System.Windows.Forms.Label()
        Me.lbl10 = New System.Windows.Forms.Label()
        Me.lbl11 = New System.Windows.Forms.Label()
        Me.lbl12 = New System.Windows.Forms.Label()
        Me.lbl13 = New System.Windows.Forms.Label()
        Me.lbl0 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbljoueur1 = New System.Windows.Forms.Label()
        Me.lbljoueur2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.BackColor = System.Drawing.Color.Transparent
        Me.lbl6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6.Location = New System.Drawing.Point(45, 224)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(18, 20)
        Me.lbl6.TabIndex = 6
        Me.lbl6.Text = "6"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.BackColor = System.Drawing.Color.Transparent
        Me.lbl7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7.Location = New System.Drawing.Point(133, 332)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(18, 20)
        Me.lbl7.TabIndex = 7
        Me.lbl7.Text = "7"
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.BackColor = System.Drawing.Color.Transparent
        Me.lbl8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8.Location = New System.Drawing.Point(234, 332)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(18, 20)
        Me.lbl8.TabIndex = 8
        Me.lbl8.Text = "8"
        '
        'lbl9
        '
        Me.lbl9.AutoSize = True
        Me.lbl9.BackColor = System.Drawing.Color.Transparent
        Me.lbl9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9.Location = New System.Drawing.Point(351, 332)
        Me.lbl9.Name = "lbl9"
        Me.lbl9.Size = New System.Drawing.Size(18, 20)
        Me.lbl9.TabIndex = 9
        Me.lbl9.Text = "9"
        '
        'lbl10
        '
        Me.lbl10.AutoSize = True
        Me.lbl10.BackColor = System.Drawing.Color.Transparent
        Me.lbl10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10.Location = New System.Drawing.Point(460, 332)
        Me.lbl10.Name = "lbl10"
        Me.lbl10.Size = New System.Drawing.Size(27, 20)
        Me.lbl10.TabIndex = 10
        Me.lbl10.Text = "10"
        '
        'lbl11
        '
        Me.lbl11.AutoSize = True
        Me.lbl11.BackColor = System.Drawing.Color.Transparent
        Me.lbl11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl11.Location = New System.Drawing.Point(579, 332)
        Me.lbl11.Name = "lbl11"
        Me.lbl11.Size = New System.Drawing.Size(27, 20)
        Me.lbl11.TabIndex = 11
        Me.lbl11.Text = "11"
        '
        'lbl12
        '
        Me.lbl12.AutoSize = True
        Me.lbl12.BackColor = System.Drawing.Color.Transparent
        Me.lbl12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl12.Location = New System.Drawing.Point(683, 332)
        Me.lbl12.Name = "lbl12"
        Me.lbl12.Size = New System.Drawing.Size(27, 20)
        Me.lbl12.TabIndex = 12
        Me.lbl12.Text = "12"
        '
        'lbl13
        '
        Me.lbl13.AutoSize = True
        Me.lbl13.BackColor = System.Drawing.Color.Transparent
        Me.lbl13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl13.Location = New System.Drawing.Point(759, 224)
        Me.lbl13.Name = "lbl13"
        Me.lbl13.Size = New System.Drawing.Size(27, 20)
        Me.lbl13.TabIndex = 13
        Me.lbl13.Text = "13"
        '
        'lbl0
        '
        Me.lbl0.AutoSize = True
        Me.lbl0.BackColor = System.Drawing.Color.Transparent
        Me.lbl0.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl0.Location = New System.Drawing.Point(683, 125)
        Me.lbl0.Name = "lbl0"
        Me.lbl0.Size = New System.Drawing.Size(18, 20)
        Me.lbl0.TabIndex = 0
        Me.lbl0.Text = "0"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.BackColor = System.Drawing.Color.Transparent
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(570, 125)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(18, 20)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "1"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.BackColor = System.Drawing.Color.Transparent
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(451, 125)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(18, 20)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "2"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.BackColor = System.Drawing.Color.Transparent
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3.Location = New System.Drawing.Point(332, 125)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(18, 20)
        Me.lbl3.TabIndex = 3
        Me.lbl3.Text = "3"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.BackColor = System.Drawing.Color.Transparent
        Me.lbl4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4.Location = New System.Drawing.Point(222, 125)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(18, 20)
        Me.lbl4.TabIndex = 4
        Me.lbl4.Text = "4"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.BackColor = System.Drawing.Color.Transparent
        Me.lbl5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5.Location = New System.Drawing.Point(117, 125)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(18, 20)
        Me.lbl5.TabIndex = 5
        Me.lbl5.Text = "5"
        '
        'lbljoueur1
        '
        Me.lbljoueur1.AutoSize = True
        Me.lbljoueur1.BackColor = System.Drawing.Color.Transparent
        Me.lbljoueur1.Font = New System.Drawing.Font("Monotype Corsiva", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbljoueur1.Location = New System.Drawing.Point(367, 41)
        Me.lbljoueur1.Name = "lbljoueur1"
        Me.lbljoueur1.Size = New System.Drawing.Size(85, 28)
        Me.lbljoueur1.TabIndex = 26
        Me.lbljoueur1.Text = "Joueur 1"
        '
        'lbljoueur2
        '
        Me.lbljoueur2.AutoSize = True
        Me.lbljoueur2.BackColor = System.Drawing.Color.Transparent
        Me.lbljoueur2.Font = New System.Drawing.Font("Monotype Corsiva", 18.0!, System.Drawing.FontStyle.Italic)
        Me.lbljoueur2.Location = New System.Drawing.Point(367, 412)
        Me.lbljoueur2.Name = "lbljoueur2"
        Me.lbljoueur2.Size = New System.Drawing.Size(85, 28)
        Me.lbljoueur2.TabIndex = 27
        Me.lbljoueur2.Text = "Joueur 2"
        '
        'Jeu_du_kalaha_Form_label
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.ClientSize = New System.Drawing.Size(850, 478)
        Me.Controls.Add(Me.lbljoueur2)
        Me.Controls.Add(Me.lbljoueur1)
        Me.Controls.Add(Me.lbl13)
        Me.Controls.Add(Me.lbl12)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl11)
        Me.Controls.Add(Me.lbl10)
        Me.Controls.Add(Me.lbl9)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl0)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl3)
        Me.Name = "Jeu_du_kalaha_Form_label"
        Me.Text = "Jeu du kalaha (Form label)"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl9 As System.Windows.Forms.Label
    Friend WithEvents lbl10 As System.Windows.Forms.Label
    Friend WithEvents lbl11 As System.Windows.Forms.Label
    Friend WithEvents lbl12 As System.Windows.Forms.Label
    Friend WithEvents lbl13 As System.Windows.Forms.Label
    Friend WithEvents lbl0 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbljoueur1 As System.Windows.Forms.Label
    Friend WithEvents lbljoueur2 As System.Windows.Forms.Label
End Class
